const { createApp, ref, reactive, onMounted, watch } = Vue;

createApp({
    setup() {
        const loggedIn = ref(false);
        const loading = ref(false);
        const error = ref('');
        const successMsg = ref('');
        const currentTab = ref('devices');
        const musicTab = ref('online');
        const loginMode = ref('password');
        const accountInfo = ref(null);

        const loginForm = reactive({ username: '', password: '', device_id: '' });
        const tokenForm = reactive({ device_id: '', user_id: '', pass_token: '' });
        const devices = ref([]);
        const selectedDevices = ref([]);
        const selectedDeviceId = ref(null);
        const searchKeyword = ref('');
        const localMusic = ref([]);
        const onlineMusic = ref([]);
        const searchResults = ref([]);
        const selectedSource = ref(null);
        const plugins = ref([]);
        const activePlugin = ref(null);
        const addPluginMode = ref('url');
        const newPlugin = reactive({ id: '', name: '', content: '', url: '' });

        const storageConfig = reactive({
            play_mode: 'online_with_cache',
            auto_download: false,
            cache_expire_seconds: 86400
        });

        const settings = reactive({
            music_directory: './music',
            download_directory: './download',
            cache_directory: './cache',
            plugins_directory: './plugins',
            verbose: false,
            play_delay_seconds: 0,
            enabled_sources: { tx: true, wy: true, kw: true, kg: true, mg: true }
        });

        const playerStatus = reactive({
            is_playing: false,
            current_track: null,
            volume: 50,
            play_mode: 'sequence'
        });

        const volume = ref(50);

        const devicePlayerStatus = ref({ status: null });
        const deviceVolume = ref(50);
        const deviceTTS = ref('');
        const deviceMusicName = ref('');

        const playlists = ref([]);
        const selectedPlaylistId = ref(null);
        const playlistView = ref('list');
        const playlistSongs = ref([]);
        const playlistSearchKeyword = ref('');
        const newPlaylistName = ref('');
        const showBatchActions = ref(false);
        const selectedPlaylistSongs = ref([]);
        const showCopyMoveDialog = ref(false);
        const copyMoveTargetPlaylistId = ref(null);
        const copyMoveOperation = ref('copy');
        const showEditPlaylistDialog = ref(false);
        const editPlaylistForm = ref({ id: null, name: '', desc: '' });
        const importPlaylistPlaylistUrl = ref('');
        const importTargetPlaylistId = ref(null);
        const showImportProgress = ref(false);
        const importAbortController = ref(null);
        const showAddToPlaylistDialog = ref(false);
        const selectedSongForPlaylist = ref(null);
        const selectedSongSource = ref('');
        const targetPlaylistIdForAdd = ref(null);

        const showPlayToDeviceDialog = ref(false);
        const selectedSongForPlay = ref(null);
        const selectedSongSourceForPlay = ref('');
        const targetDeviceIdForPlay = ref(null);

        const showPreviewDialog = ref(false);
        const previewSong = ref(null);
        const previewUrl = ref('');
        const previewLoading = ref(false);
        const previewError = ref('');
        const audioPlayer = ref(null);
        const progressTick = ref(0);
        let localProgressInterval = null;

        const showAddPluginDialog = ref(false);

        const showDeviceSettingsDialog = ref(false);
        const deviceSettingsForm = reactive({
            deviceId: '',
            currentName: '',
            name: '',
            dlnaEnabled: false,
            dlnaMeshEnabled: false
        });

        // 每台设备的DLNA状态文本: { device_id: "开启DLNA中" | "开启失败请重试" | "DLNA开启成功" }
        const dlnaStatusMap = reactive({});

        // ===== Theme Management =====
        const themeColors = [
            { name: 'green',  label: '翠绿' },
            { name: 'blue',   label: '蔚蓝' },
            { name: 'purple', label: '紫罗兰' },
            { name: 'orange', label: '暖橙' },
            { name: 'rose',   label: '玫瑰' },
            { name: 'teal',   label: '青碧' }
        ];

        const themeColor = ref('green');
        const themeMode = ref('light');
        const showThemePopover = ref(false);

        function applyTheme() {
            document.documentElement.setAttribute('data-theme', themeColor.value);
            if (themeMode.value === 'dark') {
                document.documentElement.classList.add('dark');
            } else {
                document.documentElement.classList.remove('dark');
            }
        }

        function saveTheme() {
            localStorage.setItem('xiaoai-theme-color', themeColor.value);
            localStorage.setItem('xiaoai-theme-mode', themeMode.value);
        }

        function loadTheme() {
            const savedColor = localStorage.getItem('xiaoai-theme-color');
            const savedMode = localStorage.getItem('xiaoai-theme-mode');
            if (savedColor && themeColors.some(c => c.name === savedColor)) {
                themeColor.value = savedColor;
            }
            if (savedMode === 'dark' || savedMode === 'light') {
                themeMode.value = savedMode;
            }
            applyTheme();
        }

        function setThemeColor(color) {
            themeColor.value = color;
            applyTheme();
            saveTheme();
        }

        function setThemeMode(mode) {
            themeMode.value = mode;
            applyTheme();
            saveTheme();
        }

        function showSuccess(msg) {
            successMsg.value = msg;
            setTimeout(() => { successMsg.value = ''; }, 3000);
        }

        function showError(msg) {
            error.value = msg;
            setTimeout(() => { error.value = ''; }, 3000);
        }

        const api = {
            async request(url, options = {}) {
                const { signal, ...fetchOptions } = options;
                const response = await fetch(url, {
                    headers: { 'Content-Type': 'application/json' },
                    signal,
                    ...fetchOptions
                });
                return response.json();
            },

            async post(url, data, signal = null) {
                return this.request(url, {
                    method: 'POST',
                    body: JSON.stringify(data),
                    signal
                });
            },

            async get(url) {
                return this.request(url);
            }
        };

        // 根据当前tab加载对应页面数据
        function loadTabData(tab) {
            switch (tab) {
                case 'devices':
                    loadDevices();
                    break;
                case 'plugins':
                    loadPlugins();
                    break;
                case 'music':
                    loadLocalMusic();
                    break;
                case 'playlists':
                    loadPlaylists();
                    break;
                case 'settings':
                    loadSettings();
                    loadStorageConfig();
                    break;
            }
        }

        async function checkAuth() {
            try {
                const res = await api.get('/api/auth/status');
                if (res.code === 0 && res.data.logged_in) {
                    loggedIn.value = true;
                    accountInfo.value = res.data.account;
                    loadTabData(currentTab.value);
                }
            } catch (e) {
                console.error('Check auth failed:', e);
            }
        }

        async function login() {
            if (!loginForm.username || !loginForm.password) {
                error.value = '请输入用户名和密码';
                return;
            }

            loading.value = true;
            error.value = '';

            try {
                const res = await api.post('/api/auth/login', loginForm);
                if (res.code === 0) {
                    loggedIn.value = true;
                    accountInfo.value = res.data;
                    showSuccess('登录成功！');
                    loadTabData(currentTab.value);
                } else if (res.code === 1001) {
                    error.value = '需要二次验证，请使用Token登录方式';
                    loginMode.value = 'token';
                } else {
                    error.value = res.message || '登录失败，请重试';
                }
            } catch (e) {
                error.value = '网络错误，请检查网络连接后重试';
            } finally {
                loading.value = false;
            }
        }

        async function manualLogin() {
            if (!tokenForm.device_id || !tokenForm.user_id || !tokenForm.pass_token) {
                error.value = '请填写完整的Token信息';
                return;
            }

            loading.value = true;
            error.value = '';

            try {
                const res = await api.post('/api/auth/manual', tokenForm);
                if (res.code === 0) {
                    loggedIn.value = true;
                    accountInfo.value = res.data;
                    showSuccess('Token登录成功！');
                    loadTabData(currentTab.value);
                } else {
                    error.value = res.message || 'Token登录失败，请检查信息是否正确';
                }
            } catch (e) {
                error.value = '网络错误，请检查网络连接后重试';
            } finally {
                loading.value = false;
            }
        }

        async function logout() {
            await api.post('/api/auth/logout');
            loggedIn.value = false;
            accountInfo.value = null;
            loginForm.username = '';
            loginForm.password = '';
            loginForm.device_id = '';
            tokenForm.device_id = '';
            tokenForm.user_id = '';
            tokenForm.pass_token = '';
        }

        async function loadDevices() {
            const res = await api.get('/api/device/list');
            if (res.code === 0) {
                devices.value = res.data.devices;
                const selectedDevice = res.data.devices.find(d => d.selected);
                if (selectedDevice) {
                    selectedDeviceId.value = selectedDevice.device_id;
                }

                selectedDevices.value = res.data.devices.filter(d => d.selected).map(d => d.device_id);
                syncDlnaStatusMap();
            }
        }

        async function refreshDevices() {
            const res = await api.get('/api/device/refresh');
            if (res.code === 0) {
                devices.value = res.data.devices;
                const selectedDevice = res.data.devices.find(d => d.selected);
                if (selectedDevice) {
                    selectedDeviceId.value = selectedDevice.device_id;
                }
                selectedDevices.value = res.data.devices.filter(d => d.selected).map(d => d.device_id);
                syncDlnaStatusMap();
                showSuccess('设备列表已刷新');
            }
        }

        function syncDlnaStatusMap() {
            devices.value.forEach(device => {
                const deviceId = device.device_id;
                if (device.dlna_uuid) {
                    const currentStatus = dlnaStatusMap[deviceId];
                    // 没有状态或已经是稳定状态时更新为已开启
                    if (!currentStatus || currentStatus === 'DLNA已开启' || currentStatus === 'DLNA开启成功') {
                        dlnaStatusMap[deviceId] = 'DLNA已开启';
                    }
                } else {
                    if (dlnaStatusMap[deviceId] === 'DLNA已开启') {
                        delete dlnaStatusMap[deviceId];
                    }
                }
            });
        }

        async function selectDevice(device_id) {


            if (selectedDevices.value.includes(device_id)) {
                selectedDevices.value = selectedDevices.value.filter(id => id !== device_id);
            } else {
                selectedDeviceId.value = device_id;
                selectedDevices.value.push(device_id);
                getDevicePlayerStatus(device_id);
            }

            selectDevices();


        }

        async function switchDevice(device_id) {
            if (selectedDeviceId.value == device_id) {
                selectedDeviceId.value = null;
            } else {
                selectedDeviceId.value = device_id;
            }

        }

        function getSelectedDeviceName() {
            if (!selectedDeviceId.value) return '';
            const device = devices.value.find(d => d.device_id === selectedDeviceId.value);
            return device ? (device.name || device.hardware) : selectedDeviceId.value;
        }

        async function selectDevices() {
            const res = await api.post('/api/device/select', { device_ids: selectedDevices.value });
            if (res.code === 0) {
                showSuccess('设备已选择');
            }
        }

        async function loadPlugins() {
            const res = await api.get('/api/plugin/list');
            if (res.code === 0) {
                plugins.value = res.data.plugins;
                activePlugin.value = res.data.active_plugin;
            }
        }

        async function addPlugin() {
            if (addPluginMode.value === 'url') {
                if (!newPlugin.url) {
                    alert('请输入插件链接');
                    return;
                }
            } else {
                if (!newPlugin.content) {
                    alert('请填写插件代码');
                    return;
                }
            }

            const res = await api.post('/api/plugin/add', newPlugin);
            if (res.code === 0) {
                showSuccess('插件添加成功');
                loadPlugins();
                newPlugin.id = '';
                newPlugin.name = '';
                newPlugin.content = '';
                newPlugin.url = '';
                showAddPluginDialog.value = false;
            } else {
                alert('插件添加失败: ' + (res.message || '未知错误'));
            }
        }

        async function activatePlugin(pluginId) {
            const res = await api.post('/api/plugin/activate', { plugin_id: pluginId });
            if (res.code === 0) {
                showSuccess('插件已激活');
                loadPlugins();
            }
        }

        async function deactivatePlugin(pluginId) {
            const res = await api.post('/api/plugin/deactivate', { plugin_id: pluginId });
            if (res.code === 0) {
                showSuccess('插件已停用');
                loadPlugins();
            }
        }

        async function removePlugin(pluginId) {
            if (!confirm('确定要删除这个插件吗？')) return;

            const res = await api.post('/api/plugin/remove', { plugin_id: pluginId });
            if (res.code === 0) {
                showSuccess('插件已删除');
                loadPlugins();
            }
        }

        async function loadLocalMusic() {
            const res = await api.get('/api/music/local');
            if (res.code === 0) {
                localMusic.value = res.data;
            }
        }

        async function scanLocalMusic() {
            const res = await api.post('/api/music/scan', {});
            if (res.code === 0) {
                localMusic.value = res.data;
                showSuccess('扫描完成');
            } else {
                showError('扫描失败: ' + res.message);
            }
        }

        async function deleteLocalMusic(name) {
            if (!confirm(`确定要删除 "${name}" 吗？`)) return;
            const res = await api.post('/api/music/delete', { name });
            if (res.code === 0) {
                showSuccess('删除成功');
                loadLocalMusic();
            } else {
                showError('删除失败: ' + res.message);
            }
        }

        async function renameLocalMusic(oldName) {
            const newName = prompt('请输入新名称:', oldName);
            if (!newName || !newName.trim()) return;
            const res = await api.post('/api/music/rename', { old_name: oldName, new_name: newName.trim() });
            if (res.code === 0) {
                showSuccess('重命名成功');
                loadLocalMusic();
            } else {
                showError('重命名失败: ' + res.message);
            }
        }

        async function searchMusic() {
            if (!searchKeyword.value) return;

            if (musicTab.value === 'online') {
                const res = await api.post('/api/plugin/search', {
                    keyword: searchKeyword.value,
                    page: 1,
                    limit: 20
                });

                if (res.code === 0) {
                    searchResults.value = res.data;
                    selectedSource.value = null;
                }
            } else {
                const res = await api.post('/api/music/search', {
                    keyword: searchKeyword.value
                });

                if (res.code === 0) {
                    searchResults.value = res.data.results || [];
                    selectedSource.value = null;
                }
            }
        }

        async function playMusic(music) {
            await api.post('/api/player/play', { url: music.url, name: music.name });
            // updatePlayerStatus();
        }

        async function togglePlay() {
            if (playerStatus.is_playing) {
                await api.post('/api/player/pause');
            } else {
                await api.post('/api/player/resume');
            }
            // updatePlayerStatus();
        }

        async function previousTrack() {
            await api.post('/api/player/previous');
            // updatePlayerStatus();
        }

        async function nextTrack() {
            await api.post('/api/player/next');
            // updatePlayerStatus();
        }

        async function setVolume() {
            await api.post('/api/player/volume', { volume: volume.value });
        }

        // async function updatePlayerStatus() {
        //     try {
        //         const res = await api.get('/api/player/status');
        //         if (res.code === 0) {
        //             Object.assign(playerStatus, res.data);
        //             volume.value = res.data.volume;
        //         }
        //     } catch (e) {
        //         console.error('Update player status failed:', e);
        //     }
        // }

        async function loadSettings() {
            try {
                const res = await api.get('/api/system/settings');
                if (res.code === 0) {
                    Object.assign(settings, res.data);
                }
            } catch (e) {
                console.error('Failed to load settings:', e);
            }
        }

        let deviceStatusInterval = null;
        let progressUpdateInterval = null;

        function getDeviceName(deviceId) {
            const device = devices.value.find(d => d.device_id === deviceId);
            return device ? (device.name || device.hardware) : deviceId;
        }

        async function getDevicePlayerStatus(deviceId) {
            try {
                const res = await api.post('/api/device/control/status', { device_id: deviceId });
                console.log('Device status response:', res);
                if (res.code === 0) {
                    devicePlayerStatus.value = { status: res.data.status };
                    console.log('Updated devicePlayerStatus:', devicePlayerStatus.value);
                    if (res.data.status && res.data.status.volume) {
                        deviceVolume.value = res.data.status.volume;
                    }
                }
            } catch (e) {
                console.error('Failed to get device status:', e);
            }
        }

        async function devicePlay() {
            if (!selectedDeviceId.value) return;
            try {
                const res = await api.post('/api/device/control/play', { device_id: selectedDeviceId.value });
                if (res.code === 0) {
                    showSuccess('播放成功');
                    getDevicePlayerStatus(selectedDeviceId.value);
                }
            } catch (e) {
                console.error('Failed to play:', e);
                alert('播放失败: ' + e.message);
            }
        }

        async function devicePause() {
            if (!selectedDeviceId.value) return;
            try {
                const res = await api.post('/api/device/control/pause', { device_id: selectedDeviceId.value });
                if (res.code === 0) {
                    showSuccess('暂停成功');
                    getDevicePlayerStatus(selectedDeviceId.value);
                }
            } catch (e) {
                console.error('Failed to pause:', e);
                alert('暂停失败: ' + e.message);
            }
        }

        async function deviceStop() {
            if (!selectedDeviceId.value) return;
            try {
                const res = await api.post('/api/device/control/stop', { device_id: selectedDeviceId.value });
                if (res.code === 0) {
                    showSuccess('停止成功');
                    getDevicePlayerStatus(selectedDeviceId.value);
                }
            } catch (e) {
                console.error('Failed to stop:', e);
                alert('停止失败: ' + e.message);
            }
        }

        async function setDeviceVolume() {
            if (!selectedDeviceId.value) return;
            try {
                const res = await api.post('/api/device/control/volume', { device_id: selectedDeviceId.value, volume: deviceVolume.value });
                if (res.code === 0) {
                    showSuccess('音量设置成功');
                    if (devicePlayerStatus.value.status) {
                        devicePlayerStatus.value.status.volume = deviceVolume.value;
                    }
                }
            } catch (e) {
                console.error('Failed to set volume:', e);
                alert('音量设置失败: ' + e.message);
            }
        }

        async function deviceTTSPlay() {
            if (!selectedDeviceId.value || !deviceTTS.value?.trim()) return;
            try {
                const res = await api.post('/api/device/control/tts', { device_id: selectedDeviceId.value, text: deviceTTS.value });
                if (res.code === 0) {
                    showSuccess('语音播放成功');
                    deviceTTS.value = '';
                }
            } catch (e) {
                console.error('Failed to play TTS:', e);
                alert('语音播放失败: ' + e.message);
            }
        }

        async function devicePlayMusicByName() {
            if (!selectedDeviceId.value || !deviceMusicName.value?.trim()) return;
            try {
                const res = await api.post('/api/device/control/play-music', { device_id: selectedDeviceId.value, music_name: deviceMusicName.value });
                if (res.code === 0) {
                    showSuccess('音乐播放成功');
                    deviceMusicName.value = '';
                }
            } catch (e) {
                console.error('Failed to play music:', e);
                alert('音乐播放失败: ' + e.message);
            }
        }


        watch(currentTab, (newTab) => {
            loadTabData(newTab);
        });

        watch(selectedDeviceId, (newDeviceId) => {
            if (newDeviceId) {
                getDevicePlayerStatus(newDeviceId);
                if (deviceStatusInterval) clearInterval(deviceStatusInterval);
                deviceStatusInterval = setInterval(() => {
                    getDevicePlayerStatus(newDeviceId);
                }, 5000);

                // if (progressUpdateInterval) clearInterval(progressUpdateInterval);
                // progressUpdateInterval = setInterval(() => {
                //     if (isDevicePlaying()) {
                //         getDevicePlayerStatus(newDeviceId);
                //     }
                // }, 5000);

                if (localProgressInterval) clearInterval(localProgressInterval);
                localProgressInterval = setInterval(() => {
                    if (isDevicePlaying()) {
                        progressTick.value++;
                    }
                }, 1000);
            } else {
                if (deviceStatusInterval) {
                    clearInterval(deviceStatusInterval);
                    deviceStatusInterval = null;
                }
                if (progressUpdateInterval) {
                    clearInterval(progressUpdateInterval);
                    progressUpdateInterval = null;
                }
                if (localProgressInterval) {
                    clearInterval(localProgressInterval);
                    localProgressInterval = null;
                }
            }
        });

        async function loadStorageConfig() {
            const res = await api.get('/api/system/storage/config');
            if (res.code === 0) {
                Object.assign(storageConfig, res.data);
            }
        }

        async function saveStorageConfig() {
            await api.post('/api/system/storage/config', storageConfig);
            showSuccess('存储设置已保存');
        }

        async function saveSettings() {
            // 前端校验：目录不能为空
            if (!settings.music_directory.trim()) {
                showError('音乐目录不能为空');
                return;
            }
            if (!settings.download_directory.trim()) {
                showError('下载目录不能为空');
                return;
            }
            if (!settings.cache_directory.trim()) {
                showError('缓存目录不能为空');
                return;
            }
            if (!settings.plugins_directory.trim()) {
                showError('插件目录不能为空');
                return;
            }
            if (settings.play_delay_seconds < 0) {
                showError('播放延迟不能为负数');
                return;
            }

            // 校验至少启用一个音源
            const enabledCount = Object.values(settings.enabled_sources).filter(Boolean).length;
            if (enabledCount === 0) {
                showError('至少需要启用一个音源');
                return;
            }

            try {
                const res = await api.post('/api/system/settings', {
                    music_directory: settings.music_directory,
                    download_directory: settings.download_directory,
                    cache_directory: settings.cache_directory,
                    plugins_directory: settings.plugins_directory,
                    verbose: settings.verbose,
                    play_delay_seconds: settings.play_delay_seconds,
                    enabled_sources: settings.enabled_sources
                });

                if (res.code === 0) {
                    showSuccess('系统设置已保存');
                } else {
                    showError('保存失败: ' + (res.message || '未知错误'));
                }
            } catch (e) {
                showError('保存失败: ' + e.message);
            }
        }

        async function loadPlaylists() {
            const res = await api.get('/api/playlist/list');
            if (res.code === 0) {
                playlists.value = res.data;
            }
        }

        async function createPlaylist() {
            if (!newPlaylistName.value.trim()) {
                alert('请输入歌单名称');
                return;
            }

            const res = await api.post('/api/playlist/create', {
                name: newPlaylistName.value,
                description: ''
            });

            if (res.code === 0) {
                showSuccess('歌单创建成功');
                newPlaylistName.value = '';
                loadPlaylists();
            } else {
                alert('创建失败: ' + (res.message || '未知错误'));
            }
        }

        async function selectPlaylist(id) {
            selectedPlaylistId.value = id;
            playlistView.value = 'songs';
            loadPlaylistSongs(id);
        }

        async function loadPlaylistSongs(id) {
            const res = await api.post('/api/playlist/songs', { playlist_id: id });
            if (res.code === 0) {
                playlistSongs.value = res.data;
                selectedPlaylistSongs.value = [];
            }
        }

        function editPlaylist(playlist) {
            editPlaylistForm.value = { id: playlist.id, name: playlist.name, desc: playlist.description || '' };
            showEditPlaylistDialog.value = true;
        }

        async function saveEditPlaylist() {
            const { id, name, desc } = editPlaylistForm.value;
            if (!name || !name.trim()) {
                alert('请输入歌单名称');
                return;
            }
            const res = await api.post('/api/playlist/update', {
                id,
                name: name.trim(),
                description: desc.trim() || null
            });
            if (res.code === 0) {
                showSuccess('歌单更新成功');
                showEditPlaylistDialog.value = false;
                loadPlaylists();
            } else {
                alert('更新失败: ' + (res.message || '未知错误'));
            }
        }

        async function deletePlaylist(id) {
            if (!confirm('确定要删除这个歌单吗？')) return;

            const res = await api.post('/api/playlist/delete', { id: id });
            if (res.code === 0) {
                showSuccess('歌单删除成功');
                if (selectedPlaylistId.value === id) {
                    selectedPlaylistId.value = null;
                    playlistSongs.value = [];
                }
                loadPlaylists();
            } else {
                alert('删除失败: ' + (res.message || '未知错误'));
            }
        }

        async function playPlaylist(id) {
            const res = await api.post('/api/playlist/play', { playlist_id: id });
            if (res.code === 0) {
                showSuccess('开始播放歌单');
            } else {
                alert('播放失败: ' + (res.message || '未知错误'));
            }
        }

        async function playPlaylistSong(song) {
            const res = await api.post('/api/playlist/play_one', {
                playlist_id: selectedPlaylistId.value,
                id: song.id
            });

            if (res.code === 0) {
                showSuccess('开始播放: ' + song.title);
            } else {
                alert('播放失败: ' + (res.message || '未知错误'));
            }
        }

        async function searchPlaylistSongs() {
            if (!selectedPlaylistId.value) return;

            const res = await api.post('/api/playlist/search', {
                playlist_id: selectedPlaylistId.value,
                keyword: playlistSearchKeyword.value
            });

            if (res.code === 0) {
                playlistSongs.value = res.data;
            }
        }

        async function removeSelectedSongs() {
            if (selectedPlaylistSongs.value.length === 0) return;
            if (!confirm('确定要删除选中的歌曲吗？')) return;

            const res = await api.post('/api/playlist/remove-songs', {
                playlist_id: selectedPlaylistId.value,
                song_ids: selectedPlaylistSongs.value
            });

            if (res.code === 0) {
                showSuccess('删除成功');
                selectedPlaylistSongs.value = [];
                loadPlaylistSongs(selectedPlaylistId.value);
                loadPlaylists();
            } else {
                alert('删除失败: ' + (res.message || '未知错误'));
            }
        }

        async function copyMoveSongs() {
            if (selectedPlaylistSongs.value.length === 0) return;
            if (!copyMoveTargetPlaylistId.value) {
                alert('请选择目标歌单');
                return;
            }

            const res = await api.post('/api/playlist/copy-move', {
                source_playlist_id: selectedPlaylistId.value,
                target_playlist_id: copyMoveTargetPlaylistId.value,
                song_ids: selectedPlaylistSongs.value,
                operation: copyMoveOperation.value
            });

            if (res.code === 0) {
                showSuccess('操作成功');
                showCopyMoveDialog.value = false;
                selectedPlaylistSongs.value = [];
                loadPlaylistSongs(selectedPlaylistId.value);
                loadPlaylists();
            } else {
                alert('操作失败: ' + (res.message || '未知错误'));
            }
        }

        async function importPlaylist() {
            if (!importPlaylistPlaylistUrl.value.trim()) {
                alert('请输入歌单URL');
                return;
            }

            // 创建 AbortController 用于取消请求
            const controller = new AbortController();
            importAbortController.value = controller;
            showImportProgress.value = true;

            try {
                const res = await api.post('/api/playlist/import', {
                    url: importPlaylistPlaylistUrl.value,
                    target_playlist_id: importTargetPlaylistId.value
                }, controller.signal);

                if (res.code === 0) {
                    showSuccess(`导入完成: ${res.data.imported || 0} 首歌曲`);
                    importPlaylistPlaylistUrl.value = '';
                    loadPlaylists();
                } else {
                    alert('导入失败: ' + (res.message || '未知错误'));
                }
            } catch (e) {
                if (e.name === 'AbortError') {
                    showError('导入已取消');
                } else {
                    alert('请求失败: ' + (e.message || '网络错误'));
                }
            } finally {
                showImportProgress.value = false;
                importAbortController.value = null;
            }
        }

        function cancelImport() {
            if (!confirm('确定要取消导入吗？')) return;
            if (importAbortController.value) {
                importAbortController.value.abort();
            }
        }

        function showAddToPlaylistDialogFN(song, source) {
            selectedSongForPlaylist.value = song;
            selectedSongSource.value = source;
            targetPlaylistIdForAdd.value = null;
            showAddToPlaylistDialog.value = true;
        }

        function showPlayToDeviceDialogFn(song, source_type) {
            selectedSongForPlay.value = song;
            selectedSongSourceForPlay.value = source_type;
            targetDeviceIdForPlay.value = null;
            showPlayToDeviceDialog.value = true;
        }

        async function playToDevice() {
            if (!targetDeviceIdForPlay.value) {
                alert('请选择设备');
                return;
            }

            if (!selectedSongForPlay.value) {
                alert('请先选择歌曲');
                return;
            }

            const song = selectedSongForPlay.value;
            let songId;
            if (selectedSongSourceForPlay.value === 'local') {
                songId = song.name || String(song.songmid || '');
            } else {
                songId = typeof song.songmid === 'string' ? song.songmid : String(song.songmid);
            }
            const isLocal = selectedSongSourceForPlay.value === 'local';
            const sourceValue = isLocal ? '本地音乐' : selectedSongSourceForPlay.value;

            const payload = {
                device_id: targetDeviceIdForPlay.value,
                song_id: songId,
                name: song.name || '未知歌曲',
                singer: song.singer || '未知歌手',
                duration: song.duration,
                source: sourceValue
            };
            if (isLocal) {
                payload.source_type = 'local';
            }

            const res = await api.post('/api/device/control/play-music-id', payload);

            if (res.code === 0) {
                showSuccess('播放请求已发送');
                showPlayToDeviceDialog.value = false;
            } else {
                alert('播放失败: ' + (res.message || '未知错误'));
            }
        }

        async function addSongToPlaylist() {
            if (!targetPlaylistIdForAdd.value) {
                alert('请选择目标歌单');
                return;
            }

            if (!selectedSongForPlaylist.value) {
                alert('请先选择歌曲');
                return;
            }

            const song = selectedSongForPlaylist.value;
            const res = await api.post('/api/playlist/add-song', {
                playlist_id: targetPlaylistIdForAdd.value,
                song_id: String(song.songmid),
                title: song.name || song.title,
                artist: song.singer || song.artist,
                album: song.img || '',
                duration: minutesToSeconds(song.interval || '00:00'),
                source: selectedSongSource.value,
                songmid: String(song.songmid || '')
            });

            if (res.code === 0) {
                showSuccess('歌曲已添加到歌单');
                showAddToPlaylistDialog.value = false;
                loadPlaylists();
            } else {
                alert('添加失败: ' + (res.message || '未知错误'));
            }
        }

        async function previewMusic(song, source) {
            previewSong.value = song;
            previewUrl.value = '';
            previewLoading.value = true;
            previewError.value = '';
            showPreviewDialog.value = true;

            try {
                if (source === 'local') {
                    const res = await api.post('/api/music/get-url', {
                        name: typeof song.songmid === 'string' ? song.songmid : (song.name || '')
                    });

                    if (res.code === 0) {
                        previewUrl.value = res.data.url;
                        previewLoading.value = false;
                    } else {
                        previewError.value = res.message || '获取本地音乐链接失败';
                        previewLoading.value = false;
                    }
                } else {
                    const songmid = typeof song.songmid === 'string' ? song.songmid : String(song.songmid);
                    const res = await api.post('/api/plugin/get-url', {
                        song_id: songmid,
                        source: source
                    });

                    if (res.code === 0) {
                        previewUrl.value = res.data.url;
                        previewLoading.value = false;
                    } else {
                        previewError.value = res.message || '获取音乐链接失败';
                        previewLoading.value = false;
                    }
                }
            } catch (e) {
                previewError.value = '网络错误: ' + e.message;
                previewLoading.value = false;
            }
        }

        function closePreviewDialog() {
            if (audioPlayer.value) {
                audioPlayer.value.pause();
                audioPlayer.value.currentTime = 0;
            }
            showPreviewDialog.value = false;
            previewSong.value = null;
            previewUrl.value = '';
            previewError.value = '';
        }

        function onPreviewEnded() {
            console.log('Preview ended');
        }

        // 10:00 字符串分钟转秒
        function minutesToSeconds(minutes) {
            const parts = minutes.split(':');
            return parseInt(parts[0]) * 60 + parseInt(parts[1]);
        }

        function getPlaybackStatusClass(status) {
            if (!status) return 'stopped';
            if (status === 'Playing') return 'playing';
            if (status === 'Paused') return 'paused';
            return 'stopped';
        }

        function getPlaybackStatusIconClass(status) {
            if (!status) return 'fa-solid fa-stop';
            if (status === 'Playing') return 'fa-solid fa-play';
            if (status === 'Paused') return 'fa-solid fa-pause';
            return 'fa-solid fa-stop';
        }

        function getPlaybackStatusText(status) {
            if (!status) return '已停止';
            if (status === 'Playing') return '播放中';
            if (status === 'Paused') return '已暂停';
            return '已停止';
        }

        function getProgressPercentage() {
            progressTick.value;
            if (!devicePlayerStatus.value.status || !devicePlayerStatus.value.status.current_track) {
                return 0;
            }

            const status = devicePlayerStatus.value.status;
            const track = status.current_track;

            if (!track.duration || track.duration <= 0) {
                return 0;
            }

            if (status.status === 'Playing' && status.start_time) {
                const startTime = new Date(status.start_time);
                const now = new Date();
                const elapsed = Math.floor((now - startTime) / 1000);
                const progress = (elapsed / track.duration) * 100;
                return Math.min(Math.max(progress, 0), 100);
            }

            return 0;
        }

        function getCurrentTime() {
            progressTick.value;
            if (!devicePlayerStatus.value.status || !devicePlayerStatus.value.status.current_track) {
                return 0;
            }

            const status = devicePlayerStatus.value.status;
            const track = status.current_track;

            if (!track.duration || track.duration <= 0) {
                return 0;
            }

            if (status.status === 'Playing' && status.start_time) {
                const startTime = new Date(status.start_time);
                const now = new Date();
                const elapsed = Math.floor((now - startTime) / 1000);
                return Math.min(Math.max(elapsed, 0), track.duration);
            }

            return 0;
        }

        function formatTime(seconds) {
            if (!seconds || seconds < 0) return '0:00';
            const mins = Math.floor(seconds / 60);
            const secs = Math.floor(seconds % 60);
            return `${mins}:${secs.toString().padStart(2, '0')}`;
        }

        function isDevicePlaying() {
            return devicePlayerStatus.value.status && devicePlayerStatus.value.status.status === 'Playing';
        }

        async function toggleDevicePlay() {
            if (isDevicePlaying()) {
                await devicePause();
            } else {
                await devicePlay();
            }
        }

        async function devicePrevious() {
            if (!selectedDeviceId.value) return;
            try {
                const res = await api.post('/api/device/control/previous', { device_id: selectedDeviceId.value });
                if (res.code === 0) {
                    showSuccess('切换到上一首');
                    getDevicePlayerStatus(selectedDeviceId.value);
                }
            } catch (e) {
                console.error('Failed to play previous:', e);
                alert('切换失败: ' + e.message);
            }
        }

        async function deviceNext() {
            if (!selectedDeviceId.value) return;
            try {
                const res = await api.post('/api/device/control/next', { device_id: selectedDeviceId.value });
                if (res.code === 0) {
                    showSuccess('切换到下一首');
                    getDevicePlayerStatus(selectedDeviceId.value);
                }
            } catch (e) {
                console.error('Failed to play next:', e);
                alert('切换失败: ' + e.message);
            }
        }

        function seekProgress(event) {
            if (!selectedDeviceId.value || !devicePlayerStatus.value.status || !devicePlayerStatus.value.status.current_track) {
                return;
            }

            const progressBar = event.currentTarget;
            const rect = progressBar.getBoundingClientRect();
            const clickX = event.clientX - rect.left;
            const percentage = clickX / rect.width;

            const track = devicePlayerStatus.value.status.current_track;
            const seekTime = Math.floor(percentage * track.duration);

            console.log('Seek to:', seekTime, 'seconds');
        }

        function setVolumeByClick(event) {
            if (!selectedDeviceId.value) return;

            const volumeSlider = event.currentTarget;
            const rect = volumeSlider.getBoundingClientRect();
            const clickX = event.clientX - rect.left;
            const percentage = clickX / rect.width;
            const newVolume = Math.floor(percentage * 100);

            deviceVolume.value = newVolume;
            setDeviceVolume();
        }

        function getLoopTypeClass(loopType) {
            if (!devicePlayerStatus.value.status || !devicePlayerStatus.value.status.loop_type) {
                return loopType === 'Sequence';
            }
            return devicePlayerStatus.value.status.loop_type === loopType;
        }

        async function setLoopType(loopType) {
            if (!selectedDeviceId.value) return;
            try {
                const res = await api.post('/api/device/control/loop', {
                    device_id: selectedDeviceId.value,
                    loop_type: loopType
                });
                if (res.code === 0) {
                    showSuccess('循环模式已设置');
                    getDevicePlayerStatus(selectedDeviceId.value);
                } else {
                    showError('设置失败: ' + res.message);
                }
            } catch (e) {
                console.error('Failed to set loop type:', e);
                showError('设置失败: ' + e.message);
            }
        }

        function openDeviceSettings() {
            if (!selectedDeviceId.value) return;
            const device = devices.value.find(d => d.device_id === selectedDeviceId.value);
            if (!device) return;
            deviceSettingsForm.deviceId = device.device_id;
            deviceSettingsForm.currentName = device.name || device.hardware;
            deviceSettingsForm.name = device.name || device.hardware;
            deviceSettingsForm.dlnaEnabled = device.dlna_enabled || false;
            deviceSettingsForm.dlnaMeshEnabled = device.dlna_mesh_enabled || false;
            showDeviceSettingsDialog.value = true;
        }

        async function saveDeviceSettings() {
            if (!deviceSettingsForm.deviceId) return;
            try {
                const res = await api.post('/api/device/config', {
                    device_id: deviceSettingsForm.deviceId,
                    name: deviceSettingsForm.name,
                    dlna_enabled: deviceSettingsForm.dlnaEnabled,
                    dlna_mesh_enabled: deviceSettingsForm.dlnaMeshEnabled
                });
                if (res.code === 0) {
                    showSuccess('设备设置已保存');
                    const deviceId = deviceSettingsForm.deviceId;
                    const wasDlnaEnabled = deviceSettingsForm.dlnaEnabled;
                    showDeviceSettingsDialog.value = false;

                    if (wasDlnaEnabled) {
                        // 开启DLNA后轮询设备状态
                        dlnaStatusMap[deviceId] = '开启DLNA中';
                        pollDlnaStatus(deviceId, 0);
                    }

                    loadDevices();
                } else {
                    showError('保存失败: ' + res.message);
                }
            } catch (e) {
                console.error('Failed to save device settings:', e);
                showError('保存失败: ' + e.message);
            }
        }

        async function pollDlnaStatus(deviceId, count) {
            if (count >= 20) {
                // 10次都没成功，显示失败
                dlnaStatusMap[deviceId] = '开启失败请重试';
                deviceSettingsForm.dlnaEnabled = false;
                return;
            }
            try {
                const res = await api.get('/api/device/list');
                if (res.code === 0 && res.data && res.data.devices) {
                    const device = res.data.devices.find(d => d.device_id === deviceId);
                    if (device) {
                        if (device.dlna_enabled === false) {
                            dlnaStatusMap[deviceId] = '开启失败请重试';
                            deviceSettingsForm.dlnaEnabled = false;
                            return;
                        }
                        if (device.dlna_uuid) {
                            dlnaStatusMap[deviceId] = 'DLNA开启成功';
                            return;
                        }
                    }
                }
            } catch (e) {
                console.error('DLNA status poll error:', e);
            }
            // 1秒后继续轮询
            setTimeout(() => pollDlnaStatus(deviceId, count + 1), 1000);
        }

        onMounted(() => {
            loadTheme();
            checkAuth();
        });

        return {
            loggedIn, loading, error, successMsg, currentTab, musicTab, loginMode, accountInfo,
            loginForm, tokenForm, devices, selectedDeviceId, searchKeyword,
            localMusic, onlineMusic, searchResults, selectedSource, plugins, activePlugin, addPluginMode, newPlugin,
            storageConfig, settings, playerStatus, volume,
            devicePlayerStatus, deviceVolume, deviceTTS, deviceMusicName, selectedDevices,
            playlists, selectedPlaylistId, playlistView, playlistSongs, playlistSearchKeyword,
            newPlaylistName, showBatchActions, selectedPlaylistSongs, showCopyMoveDialog,
            copyMoveTargetPlaylistId, copyMoveOperation, importPlaylistPlaylistUrl, importTargetPlaylistId, showImportProgress, editPlaylistForm, showEditPlaylistDialog,
            showAddToPlaylistDialog, selectedSongForPlaylist, selectedSongSource, targetPlaylistIdForAdd,
            showPlayToDeviceDialog, selectedSongForPlay, selectedSongSourceForPlay, targetDeviceIdForPlay,
            showPreviewDialog, previewSong, previewUrl, previewLoading, previewError, audioPlayer, progressTick,
            showAddPluginDialog,
            showDeviceSettingsDialog, deviceSettingsForm, dlnaStatusMap,
            themeColors, themeColor, themeMode, showThemePopover,
            setThemeColor, setThemeMode,
            login, manualLogin, logout, loadDevices, refreshDevices, selectDevice, getSelectedDeviceName,
            loadPlugins, addPlugin, activatePlugin, deactivatePlugin, removePlugin,
            loadLocalMusic, searchMusic, playMusic, scanLocalMusic, deleteLocalMusic, renameLocalMusic,
            togglePlay, previousTrack, nextTrack, setVolume, saveStorageConfig, saveSettings,
            getDevicePlayerStatus, devicePlay, devicePause, deviceStop,
            setDeviceVolume, deviceTTSPlay, devicePlayMusicByName, switchDevice,
            loadPlaylists, createPlaylist, selectPlaylist, loadPlaylistSongs, editPlaylist, saveEditPlaylist,
            deletePlaylist, playPlaylist, playPlaylistSong, searchPlaylistSongs,
            removeSelectedSongs, copyMoveSongs, importPlaylist, cancelImport, showAddToPlaylistDialogFN, addSongToPlaylist,
            showPlayToDeviceDialogFn, playToDevice,
            previewMusic, closePreviewDialog, onPreviewEnded,
            getPlaybackStatusClass, getPlaybackStatusIconClass, getPlaybackStatusText,
            getProgressPercentage, getCurrentTime, formatTime, isDevicePlaying,
            toggleDevicePlay, devicePrevious, deviceNext, seekProgress,
            setVolumeByClick, getLoopTypeClass, setLoopType,
            openDeviceSettings, saveDeviceSettings
        };
    }
}).mount('#app');